# Plan: Separate tenant authentication into `account` and `user_profile`

## Objective

Redesign tenant user identity in `restate-xstate` so that authentication credentials and user profile data live in separate tables, a single person can log in through multiple auth providers, and a single person can join multiple companies while keeping company-specific membership data isolated in each tenant namespace.

## Current state

- **Platform admin auth** (`apps/admin`) uses `platform_users` in the `platform/admin` namespace. It stores `email` + bcrypt `password` hash together. This is out of scope; it stays as-is.
- **Tenant users** (`packages/db/src/tenant.ts`) currently has a `users` table with `name`, `email`, `status`. No auth credentials yet.
- **Company management** is done: each company gets a SurrealDB namespace `company_<uuid-without-hyphens>/main`, resolved by cookie (`company_slug`) or header (`x-company-namespace`) in `apps/web/server/middleware/company.ts`.
- **Web app users API** (`apps/web/server/api/users/*.ts`) CRUDs the tenant `users` table and dispatches workflow triggers on create.
- **ADR-004** already mandates bcrypt for password hashing.
- There is no `docs/50-Features/Authentication & Authorization.md` feature note yet, despite references in the atlas.

## Design decisions

1. **Tenant-only scope**. Platform admin keeps `platform_users` as a simple email/password table.
2. **Global identity tables** live in the `platform` namespace:
   - `account` — one row per login method (email, OAuth, phone, etc.).
   - `user_profile` — one row per person; holds profile fields and personal preferences.
3. **Per-company membership** lives in each company namespace as `member`:
   - Links a global `user_profile` to the company.
   - Holds role, permissions, join timestamp, inviter, status.
4. **Company branding overrides** (theme color, logo) stay on the `companies` record or a new `company_settings` table — not on `member`.
5. **Existing tenant `users` table is deprecated** and replaced by `member` + global `user_profile`.

## Proposed data model

### Global namespace (`platform/admin`)

```
account
  id              : record id
  provider        : "email" | "oauth_google" | "oauth_github" | "phone" | ...
  provider_key    : string   // email address, phone number, OAuth sub, etc.
  credential      : string?  // bcrypt hash for email; OAuth token ref / empty for OAuth
  profile_id      : -> user_profile
  created_at      : datetime
  updated_at      : datetime

user_profile
  id              : record id
  name            : string
  gender          : string?
  birthday        : string?  // ISO date
  preferences     : object   // { colorMode, language, ... }
  created_at      : datetime
  updated_at      : datetime
```

Indexes:
- `idx_account_provider_key` on `account` fields `provider, provider_key` UNIQUE.
- `idx_user_profile_name` on `user_profile` fields `name` (optional, for search).

### Tenant namespace (`company_<uuid>/main`)

```
member
  id              : record id
  profile_id      : string?  // global user_profile id; null while invite is pending
  email           : string   // email the invite was sent to; used to match on accept
  role            : string   // "owner" | "admin" | "member"
  status          : "pending" | "active" | "inactive"
  invite_code     : string?  // random hash for pending invites; cleared on accept
  joined_at       : datetime // set when status becomes active
  invited_by      : string?  // member id of inviter
  created_at      : datetime
  updated_at      : datetime
```

Indexes:
- `idx_member_profile` on `member` field `profile_id` (for active members).
- `idx_member_invite_code` on `member` field `invite_code` UNIQUE per company (for invite acceptance).

## Auth flow

1. **Login / identify account**: Look up `account` by `(provider, provider_key)` in global namespace.
2. **Validate credential** (for email provider, compare bcrypt hash; for OAuth, verify token with provider).
3. **Resolve profile**: `account.profile_id -> user_profile`.
4. **Resolve active company**: Web app still uses `company_slug` cookie / `x-company-namespace` header via existing middleware.
5. **Resolve membership**: In the active company namespace, `SELECT * FROM member WHERE profile_id = $profileId AND status = 'active'`.
6. **Build session**: Store `account_id`, `profile_id`, `company_id`, `member_id`, `role`.

### Invite acceptance flow

1. Admin creates pending `member` with `email` and random `invite_code`.
2. Invitee visits invite link and submits email/password (or OAuth consent).
3. Server verifies `invite_code`, creates/claims `user_profile`, creates/updates `account`, links `member.profile_id`, sets `status = 'active'`, clears `invite_code`.
4. New session is established for the company.

## Files and packages to change

### `packages/db`

- `src/platform.ts`
  - Add CRUD functions for `account` and `user_profile`.
  - Add lookup by `(provider, provider_key)`.
- `src/tenant.ts`
  - Add `MemberRecord` / `MemberInput` interfaces and CRUD functions.
  - Remove `UserRecord` / `UserInput` and `users` CRUD functions; replace with `member` functions.
- `src/seed.ts`
  - Keep `platform_users:admin` seed untouched.
  - No tenant auth seed needed yet.
- `src/index.ts`
  - Export new types/functions.

### `packages/shared`

- `src/auth.ts`
  - Already has `hashPassword` / `comparePassword`; consider adding provider enum or constants.

### `apps/web`

- `server/api/users/*.ts`
  - Replace `users` CRUD with `member` + `user_profile` operations.
  - `GET /api/users` → list members of current company and join with global profiles.
  - `POST /api/users` → create global `user_profile` and `account` (email + temp/invited password) if new, then create `member` in current company.
  - `PATCH /api/users/:id` → update membership fields or profile fields.
  - `DELETE /api/users/:id` → remove membership (soft delete via status?) or hard delete.
- `server/middleware/company.ts`
  - Optionally enrich `event.context` with resolved `member` / role after company resolution.
- `server/utils/auth.ts` (new)
  - Session helpers for tenant users analogous to admin session utils.
- `app/pages/users/index.vue`
  - Update to display member + profile data.

### `apps/admin`

- No auth changes; platform auth stays as-is.

### Documentation

- Create `docs/50-Features/Authentication & Authorization.md` with feature frontmatter.
- Update `docs/20-Architecture/Data Model.md` to show `account`, `user_profile`, `member`.
- Update `docs/50-Features/Company Management.md` if membership behavior needs clarification.
- Update `docs/00-Atlas/Project Brief.md` `updated:` date if scope changes.

## Implementation steps

1. **Design sign-off** (this plan).
2. **Update global schema and db package**:
   - Add `account` and `user_profile` tables/indexes to `packages/db/src/platform.ts`.
   - Add `member` table/indexes to `packages/db/src/tenant.ts`.
   - Remove existing tenant `users` functions; drop any existing `users` records (no migration).
3. **Add tenant auth utilities**:
   - Create `apps/web/server/utils/auth.ts` with session cookie helpers.
   - Add middleware enrichment for `member` context.
4. **Rewrite web users API**:
   - Update `apps/web/server/api/users/*.ts` to operate on `member` + `user_profile`.
   - `POST /api/users` creates a pending `member` with an `invite_code`.
   - `POST /api/users/accept-invite` (or similar) accepts an invite: creates/claims `user_profile` + `account`, links `member.profile_id`, sets status to `active`.
   - Ensure workflow triggers still fire on member activation.
5. **Update UI**:
   - Adjust `apps/web/app/pages/users/index.vue` fields and forms.
6. **Add login endpoint** (minimal first version):
   - `POST /api/auth/login` for email/password.
   - Resolve account → profile → company → member, set session cookie.
7. **Tests / verification**:
   - Build passes: `pnpm -r build`.
   - DB package compiles.
   - Web app starts and users page loads.
   - Manual login + user invite flow works.
8. **Documentation**:
   - Write `docs/50-Features/Authentication & Authorization.md`.
   - Update Data Model note.

## Verification criteria

- `pnpm -r build` succeeds.
- `packages/db` TypeScript compiles.
- Tenant `member` table can be created, read, updated, deleted via web API.
- A single `user_profile` can have multiple `account` records.
- A single `user_profile` can be a `member` of multiple companies.
- Existing company resolution middleware still works.

## Decisions from review

1. **Invitation flow**: When an admin invites a user by email, create a `member` record in the company namespace with status `pending` and a random invite code. Do **not** create an `account` yet. The invitee accepts the invite and creates/claims their `account` (and `user_profile` if new) afterward.
2. **Role model**: Use a simple string `role` (`owner`, `admin`, `member`).
3. **Session storage**: Use a JSON cookie, consistent with the admin app.
4. **Cross-namespace queries**: Query global namespace for `account`/`user_profile`, then query the active company namespace for `member`. Two round-trips.
5. **Existing tenant `users` data**: No migration. Existing tenant `users` records can be dropped; the table is replaced by `member` + global `user_profile`.
